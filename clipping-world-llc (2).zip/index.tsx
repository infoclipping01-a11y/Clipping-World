// This application has been converted to a static HTML/JS site in index.html.
// React is no longer used.
console.log("Static Mode Active");